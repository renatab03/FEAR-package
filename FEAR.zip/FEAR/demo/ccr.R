# Estimate input weak technical efficiency in the sample used by
# Charnes et al. (1981), Management Science 27, 668--697.
# p = number of inputs
# q = number of outpus
# n = number of banks
#
data(ccr)
attach(ccr)
p=5
q=3
n=70
x=matrix(nrow=p,ncol=n)
y=matrix(nrow=q,ncol=n)
x[1,]=x1
x[2,]=x2
x[3,]=x3
x[4,]=x4
x[5,]=x5
y[1,]=y1
y[2,]=y2
y[3,]=y3
rm(ccr)
##
##
##
time0=proc.time()
dhat=dea(x,y)
time1=proc.time()
h=eff.bw(dhat)
show.dens(dhat,bw=h)

nrep=1000
dboot=matrix(nrow=n,ncol=nrep)
xstar=matrix(nrow=p,ncol=n)
for (i in 1:nrep) {
   dstar=dea.resample(dhat,bw=h)
   fac=matrix(dstar/dhat,nrow=1)
   #xstar=aperm(apply(x,1,FUN="*",fac))
   for (j in 1:p) {
      xstar[j,]=x[j,]*fac
      }
   ystar=y
   dshat=dea(x,y,XREF=xstar,YREF=ystar)
   dboot[,i]=dshat
   }
dbm=apply(dboot,1,mean)
dbias=dhat-dbm
dvar=apply(dboot,1,var)
qq=matrix(nrow=n,ncol=6)
for (i in 1:n) {
   dboot[i,]=dboot[i,]-dhat[i]
   q=quantile(dboot[i,],probs=c(0.050,0.025,0.001,0.95,0.975,0.995),na.rm=TRUE)
   qq[i,]=q
   }
b=-qq[,1:3]
a=-qq[,4:6]
clo=matrix(nrow=n,ncol=3)
chi=matrix(nrow=n,ncol=3)
for (i in 1:n) {
   clo[i,]=dhat[i]+a[i,]
   chi[i,]=dhat[i]+b[i,]
   }
time2=proc.time()
t1=time1-time0
t2=time2-time1
print(t1[1:3])
print(t2[1:3])
result=matrix(nrow=n,ncol=9)
##
## result is organized as follows:
##    column 1: input efficiency estimate
##    column 2: bootstrap bias estimate
##    column 3: bootstrap variance estimate
##    column 4: bootstrap estimate of lower bound for 90-percent CI
##    column 5: bootstrap estimate of upper bound for 90-percent CI
##    column 6: bootstrap estimate of lower bound for 95-percent CI
##    column 7: bootstrap estimate of upper bound for 95-percent CI
##    column 8: bootstrap estimate of lower bound for 99-percent CI
##    column 9: bootstrap estimate of upper bound for 99-percent CI
result[,1]=dhat
result[,2]=dbias
result[,3]=dvar
result[,4]=clo[,1]
result[,5]=chi[,1]
result[,6]=clo[,2]
result[,7]=chi[,2]
result[,8]=clo[,3]
result[,9]=chi[,3]
##
## make a file with TeX source for table:
tmp=matrix(nrow=n,ncol=6)
tmp[,1]=c(1:n)
tmp[,2]=result[,1]
tmp[,3]=result[,2]
tmp[,4]=result[,3]
tmp[,5]=result[,6]
tmp[,6]=result[,7]
ztmp=tex.table(tmp[1:35,],tnum=1,cskip="enspace",
               clab=c("obs","$\\hat\\theta$","bias","var","lo","hi"))

