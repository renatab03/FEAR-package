p=1    # number of inputs
q=1    # number of outputs
n=10   # number of observations
##
## generate input, output data:
x=matrix(runif(n),nrow=p,ncol=n)
y=x*exp(-0.5*abs(rnorm(n)))
##
## estimate vrs, crs efficiencies for input orientation:
dist=dea(x,y)
dcrs=dea(x,y,RTS=3)
##
## make some plots:
dmax=max(dist,dcrs)
par(mfrow=c(3,1),pty="s")
plot(x,y,type="p",xlab="input",ylab="output")
plot(x,dist,type="p",xlab="input",ylab="vrs efficiency",ylim=c(1,dmax))
plot(x,dcrs,type="p",xlab="input",ylab="crs efficiency",ylim=c(1,dmax))
