print("perform outlier analysis on Charnes et al. (1981) data as in Wilson (1993)")
data(ccr)
attach(ccr)
x=matrix(nrow=5,ncol=70)
x[1,]=x1
x[2,]=x2
x[3,]=x3
x[4,]=x4
x[5,]=x5
y=matrix(nrow=3,ncol=70)
y[1,]=y1
y[2,]=y2
y[3,]=y3
#
# perform outlier analysis on Charnes et al. (1981) data as in Wilson (1993):
clock1=proc.time()
date1=date()
aa=ap(X=x,Y=y,NDEL=12)
#
# report time used:
clock2=proc.time()
date2=date()
dclock=clock2-clock1
print(paste("started ",date1,sep=""),quote=FALSE)
print(paste("   user time  =",dclock[1],sep=""),quote=FALSE)
print(paste("   system time=",dclock[2],sep=""),quote=FALSE)
print(paste("   wall time  =",dclock[3],sep=""),quote=FALSE)
print(paste("ended   ",date2,sep=""),quote=FALSE)
#
# print results:
print(aa$r0)
print(aa$imat)
#
# produce the log-ratio plot as in Wilson (1993):
ap.plot(aa$ratio)

